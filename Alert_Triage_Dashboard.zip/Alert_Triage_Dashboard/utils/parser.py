import pandas as pd
import re
from datetime import datetime

def parse_syslog(file_path):
    with open(file_path, "r") as f:
        lines = f.readlines()

    data = []
    for line in lines: #<<<<matching the syslog format for timestamp and IP address
        
        match = re.match(
            r'^(?P<timestamp>\w{3} \d{1,2} \d{2}:\d{2}:\d{2}) .*? from (?P<ip>\d+\.\d+\.\d+\.\d+)',
            line
        )
        if match:
            entry = match.groupdict()
            
            #<<<< then converted the  syslog timestamp to datetime with current year
            try:
                entry["timestamp"] = datetime.strptime(
                    f"{datetime.now().year} {entry['timestamp']}", "%Y %b %d %H:%M:%S"
                )
            except:
                entry["timestamp"] = None
            
            data.append(entry)

    return pd.DataFrame(data)