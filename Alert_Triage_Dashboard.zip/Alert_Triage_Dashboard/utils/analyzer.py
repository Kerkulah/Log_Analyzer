import pandas as pd

def detect_suspicious(df):  #<<<< function to detect suspicious activity based on failed attempts
    if "ip" not in df.columns or "message" not in df.columns:
        return pd.DataFrame()

    failed = df[df["message"].str.contains("failed", case=False, na=False)]
    grouped = failed.groupby("ip").size().reset_index(name="failed_attempts")
    return grouped[grouped["failed_attempts"] > 2]
