import pandas as pd
import json
from datetime import datetime

def parse_windows_eventlog(filepath):
    with open(filepath, 'r') as f:
        logs = json.load(f)

    parsed = [] #<<<< list to hold parsed log entries
    for entry in logs:
        timestamp = entry.get("TimeCreated", {}).get("SystemTime")
        message = entry.get("Message", "")
        ip = None
        if "Source Network Address" in message:
            parts = message.split("Source Network Address:")
            if len(parts) > 1:
                ip = parts[1].split()[0].strip()

        parsed.append({
            "timestamp": pd.to_datetime(timestamp),
            "message": message,
            "ip": ip,
            "severity": "HIGH" if "failed" in message.lower() else "INFO"
        })

    return pd.DataFrame(parsed)
